package com.example.prefijo;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        TextView missatgeError = findViewById(R.id.error);
        EditText nom = findViewById(R.id.nom);
        EditText email = findViewById(R.id.emailContacte);
        Spinner selector = findViewById(R.id.selector);
        EditText missatge = findViewById(R.id.missatgeMail);
        CheckBox checkBox = findViewById(R.id.check);
        Button botoPreparar = findViewById(R.id.prepararCorreu);

        botoPreparar.setOnClickListener(v -> {
            String nomText = nom.getText().toString().trim();
            String emailText = email.getText().toString().trim();
            String missatgeText = missatge.getText().toString().trim();

            if (nomText.isEmpty() || emailText.isEmpty() || missatgeText.isEmpty()) {
                missatgeError.setText("Por favor, completa todos los campos");
                return;
            }

            String valorCheckBox = checkBox.getText().toString().trim();
            String assumpte = nomText + " - " + valorCheckBox;

            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:" + Uri.encode(emailText)));
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{emailText});
            intent.putExtra(Intent.EXTRA_SUBJECT, assumpte);
            intent.putExtra(Intent.EXTRA_TEXT, missatgeText);

            try {
                startActivity(intent);
            } catch (ActivityNotFoundException e) {
                missatgeError.setText("No se encontró ninguna aplicación de correo");;
            }
        });
    }
}